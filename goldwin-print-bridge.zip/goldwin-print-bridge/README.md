# GoldWin Print Bridge

A tiny, invisible companion Android app for the GoldWin lottery POS app.

## What it does

Normally, printing from a website requires the Android print dialog to pop
up, showing a preview of the page (including the win/lose result) before
the customer taps a "Print" button. This app removes that dialog entirely.

When the GoldWin web app wants to print a receipt, it opens a special link
(`goldwinprint://receipt?data=...`). This app catches that link, silently
sends the receipt straight to the device's built-in printer using Sunmi's
official printer service, and closes itself immediately — usually within a
fraction of a second, with no screen ever appearing.

## Requirements

- A Sunmi-branded POS device (or one running genuine Sunmi OS/printer
  service) with a built-in thermal printer.

## Building the APK (no computer setup needed)

1. Create a new **public or private** repository on GitHub.
2. Upload every file in this folder to that repository (keeping the same
   folder structure).
3. Go to the repository's **Actions** tab.
4. Click **Build APK** in the left sidebar, then click **Run workflow**
   (top right) → **Run workflow** again to confirm.
5. Wait about 2-3 minutes for it to finish (a green checkmark appears).
6. Click on the finished run, scroll down to **Artifacts**, and download
   **GoldWinPrintBridge-debug-apk** (this downloads a .zip containing the
   .apk file).

## Installing on the POS device

1. Unzip the downloaded file to get `app-debug.apk`.
2. Transfer it to the POS device (e.g. via a USB cable, or upload it
   somewhere and download it in the device's browser).
3. On the device, open the APK file to install it. You may need to enable
   "Install from unknown sources" the first time — Android will prompt you
   for this automatically if needed.
4. That's it — no need to ever open this app manually. It only activates
   when the GoldWin web app asks it to print.

## Testing it

Once installed, buy a ticket in the GoldWin app as normal. If everything is
set up correctly, the receipt should print with no dialog or popup ever
appearing on screen.
